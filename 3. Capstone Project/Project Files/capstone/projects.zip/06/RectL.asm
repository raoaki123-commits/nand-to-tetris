// This file is part of www.nand2tetris.org
// and the book "The Elements of Computing Systems"
// by Nisan and Schocken, MIT Press.
// File name: projects/6/rect/RectL.asm

// Symbol-less version of the Rect.asm program.
// Designed for testing the basic version of the assembler.

@0
D=M
@23
D;JLE 
@16
M=D
@16384
D=A
@17
M=D
@17
A=M
M=-1
@17
D=M
@32
D=D+A
@17
M=D
@16
DM=M-1
@10
D;JGT
@23
0;JMP